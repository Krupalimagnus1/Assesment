export class Item {
  name: string;
  sellIn: number;
  quality: number;

  constructor(name, sellIn, quality) {
    this.name = name;
    this.sellIn = sellIn;
    this.quality = quality;
  }
}

export class GildedRose {
  items: Array<Item>;
  public static readonly MAX_VALUE = 50;
  public static readonly MIN_VALUE = 0;
  constructor(items = [] as Array<Item>) {
    this.items = items;
  }

  updateQuality() {
    for (let i = 0; i < this.items.length; i++) {

      if (this.items[i].name == 'Aged Brie') {
        this.items[i].sellIn = this.decreaseSellIn(this.items[i].sellIn,1);
        this.items[i].quality = this.increaseQuantity(this.items[i].quality,1);
      } else if (this.items[i].name == 'Backstage passes to a TAFKAL80ETC concert'){
        this.items[i].sellIn = this.decreaseSellIn(this.items[i].sellIn,1);
        if (this.items[i].sellIn <= 0) {
          this.items[i].quality = 0;
        } else if (this.items[i].sellIn < 5) {
          this.items[i].quality = this.increaseQuantity(this.items[i].quality,3);
        } else if (this.items[i].sellIn < 10) {
          this.items[i].quality = this.increaseQuantity(this.items[i].quality,2);
        } else if (this.items[i].sellIn > 10) {
          this.items[i].quality = this.increaseQuantity(this.items[i].quality,1);
        }
      }else if (this.items[i].name == 'Sulfuras, Hand of Ragnaros'){

      }else if (this.items[i].name == 'Conjured Mana Cake'){
        this.items[i].sellIn = this.decreaseSellIn(this.items[i].sellIn,1);
        this.items[i].quality = this.isExpired(this.items[i].sellIn)
        ? this.decreaseQuantity(this.items[i].quality, 4)
        : this.decreaseQuantity(this.items[i].quality, 2);
      } else {
        this.items[i].sellIn = this.decreaseSellIn(this.items[i].sellIn,1);
        this.items[i].quality = this.isExpired(this.items[i].sellIn)
        ? this.decreaseQuantity(this.items[i].quality, 2)
        : this.decreaseQuantity(this.items[i].quality, 1);
      }
    }

    return this.items;
  }


  decreaseSellIn(value: number,decreaseBy: number): number {
    return value - decreaseBy;
  }

  decreaseQuantity(value: number,decreaseBy: number): number {
    if (value > GildedRose.MIN_VALUE) {
      return value - decreaseBy;
    } else {
      return value;
    }
  }

  increaseQuantity(value: number,increaseBy: number): number {
    if (value < GildedRose.MAX_VALUE) {
      return value + increaseBy;
    } else {
      return value;
    }
  }

  isExpired(sellInValue: number): boolean {
    return sellInValue < 0 ? true : false;
  }

}
