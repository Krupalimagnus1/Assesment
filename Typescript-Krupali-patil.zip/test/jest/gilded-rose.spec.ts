import { Item, GildedRose } from '@/gilded-rose';

describe('Gilded Rose', () => {
  it('should foo', () => {
    const gildedRose = new GildedRose([new Item('foo', 0, 0)]);
    const items = gildedRose.updateQuality();
    expect(items[0].name).toBe('foo');
  });
});

describe('when update the quality of the items', () => {
  describe('and is a standard item', () => {
    describe('and the sell date has not expired', () => {
      it('should decrease both "sellIn" and "qualily" values in one', () => {
        const  gildedRose = new GildedRose([getStandardItemNotExpired()]);
        const expectedSellInValue =
          gildedRose.items[0].sellIn - 1;
        const expectedQualityValue =
          gildedRose.items[0].quality - 1;

        gildedRose.updateQuality();
        const updatedStandardItem = gildedRose.items[0];

        expect(updatedStandardItem.sellIn).toEqual(
          expectedSellInValue
        );
        expect(updatedStandardItem.quality).toEqual(
          expectedQualityValue
        );
      });
    });

    describe('and the sell date has expired', () => {
      it('should decrease the qualily twice as fast', () => {
        const gildedRose = new GildedRose([getStandardItemExpired()]);
        const qualityValue = gildedRose.items[0].quality;
        const expectedQuality = qualityValue - 2;
        gildedRose.updateQuality();

        const updatedStandardItem = gildedRose.items[0];

        expect(updatedStandardItem.quality).toEqual(
          expectedQuality
        );
      });
    });
  });

  describe('and is an AgedBrieItem', () => {
    it('should increase the qualily value and decrease de sellIn value', () => {
      const agedBrieItem = getAgedBrieItemExpired();
      const gildedRose = new GildedRose([agedBrieItem]);
      const expectedQuality = agedBrieItem.quality + 1;
      const expectedSellIn = agedBrieItem.sellIn - 1;

      gildedRose.updateQuality();

      const updatedAgedBrieItem = gildedRose.items[0];

      expect(updatedAgedBrieItem.quality).toEqual(
        expectedQuality
      );

      expect(updatedAgedBrieItem.sellIn).toEqual(
        expectedSellIn
      );
    });
  });
  describe('and is a BackStagePasses', () => {
    describe('and the sell date has not expired', () => {
      it('should increase qualily in one if sellIn is greater than 10 days', () => {
        const backStagePass = new GildedRose([new Item('Backstage passes to a TAFKAL80ETC concert', 20, 15)]);

        const expectedSellIn = 19;
        const expectedQuality = 16;

        const gildedRose = new GildedRose([new Item('Backstage passes to a TAFKAL80ETC concert', 20, 15)]);

        gildedRose.updateQuality();

        const updatedBackStagePassItem = gildedRose.items[0];

        expect(updatedBackStagePassItem.sellIn).toEqual(
          expectedSellIn
        );
        expect(updatedBackStagePassItem.quality).toEqual(
          expectedQuality
        );
      });

      it('should increase qualily in two if sellIn is between 10 and 6 days ', () => {
        const backStagePass = new GildedRose([new Item('Backstage passes to a TAFKAL80ETC concert', 9, 15)]);

        const expectedSellIn = 8;
        const expectedQuality = 17;

        const gildedRose = new GildedRose([new Item('Backstage passes to a TAFKAL80ETC concert', 9, 15)]);

        gildedRose.updateQuality();

        const updatedBackStagePassItem = gildedRose.items[0];

        expect(updatedBackStagePassItem.sellIn).toEqual(
          expectedSellIn
        );
        expect(updatedBackStagePassItem.quality).toEqual(
          expectedQuality
        );
      });

      it('should increase qualily in 3 if sellIn is between 5 and 1 days ', () => {
        const backStagePass = new GildedRose([new Item('Backstage passes to a TAFKAL80ETC concert', 4, 15)]);

        const expectedSellIn = 3;
        const expectedQuality = 18;

        const gildedRose = new GildedRose([new Item('Backstage passes to a TAFKAL80ETC concert', 4, 15)]);;

        gildedRose.updateQuality();

        const updatedBackStagePassItem = gildedRose.items[0];

        expect(updatedBackStagePassItem.sellIn).toEqual(
          expectedSellIn
        );
        expect(updatedBackStagePassItem.quality).toEqual(
          expectedQuality
        );
      });

      it('should drops to 0 qualily value if the sell date has expired ', () => {
        const backStagePass = new GildedRose([new Item('Backstage passes to a TAFKAL80ETC concert', 0, 15)]);;

        const expectedSellIn =  -1;
        const expectedQuality = 0;

        const gildedRose = new GildedRose([new Item('Backstage passes to a TAFKAL80ETC concert', 0, 15)]);

        gildedRose.updateQuality();

        const updatedBackStagePassItem = gildedRose.items[0];

        expect(updatedBackStagePassItem.sellIn).toEqual(
          expectedSellIn
        );
        expect(updatedBackStagePassItem.quality).toEqual(
          expectedQuality
        );
      });
    });
  });
  describe('and is a ConjuredItem', () => {
    describe('and the sell date has not expired', () => {
      it('should decrease both "sellIn" and "qualily" values in two', () => {
        const conjuredItem = new GildedRose([new Item('Conjured Mana Cake', 10, 20)]);
        const gildedRose = new GildedRose([new Item('Conjured Mana Cake', 10, 20)]);

        const expectedSellIn = 9;
        const expectedQuality = 18;

        gildedRose.updateQuality();

        const updatedConjuredItem = gildedRose.items[0];

        expect(updatedConjuredItem.sellIn).toEqual(
          expectedSellIn
        );

        expect(updatedConjuredItem.quality).toEqual(
          expectedQuality
        );
      });

      describe('and the sell date has expired', () => {
        it('should decrease the qualily twice as fast', () => {
          const expiredConjuredItem = new GildedRose([new Item('Conjured Mana Cake',-1, 20)])
          const gildedRose = new GildedRose([new Item('Conjured Mana Cake', -1, 20)])

          const expectedSellIn = -2;
          const expectedQuality = 16;

          gildedRose.updateQuality();

          const updatedConjuredItem = gildedRose.items[0];

          expect(updatedConjuredItem.sellIn).toEqual(
            expectedSellIn
          );

          expect(updatedConjuredItem.quality).toEqual(
            expectedQuality
          );
        });
      });
    });
  });
  describe('and is a SufurasItem', () => {
    it('should not modify any after being updated', () => {
      const sulfurasItem = new GildedRose([new Item('Sulfuras, Hand of Ragnaros', 0, 50)]);

      const gildedRose = new GildedRose([new Item('Sulfuras, Hand of Ragnaros', 0, 50)]);

      gildedRose.updateQuality();

      const updatedSulfurasItem = gildedRose.items[0];
      expect(updatedSulfurasItem.sellIn).toEqual(0);
      expect(updatedSulfurasItem.quality).toEqual(50);
    });
  });

  function getStandardItemNotExpired() {
    return new Item('+5 Dexterity Vest', 5, 10);
  }

  function getStandardItemExpired() {
    return new Item('+5 Dexterity Vest', 0, 10);
  }

  function getAgedBrieItemExpired() {
    return new Item('Aged Brie', 10, 10);
  }

});
